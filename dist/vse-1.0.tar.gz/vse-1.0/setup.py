from setuptools import setup, find_packages

setup(
   name='vse',
   version='1.0',
   description='Validation Scripting Engine',
   author='Courtney S Baxter Jr',
   author_email='cbaxtertech@gmail.com',
   packages=find_packages(),

)

