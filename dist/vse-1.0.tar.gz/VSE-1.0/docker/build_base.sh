#!/usr/bin/env bash

cd ..

docker build .  -f docker/base.Dockerfile -t cbaxter1988/vse:base