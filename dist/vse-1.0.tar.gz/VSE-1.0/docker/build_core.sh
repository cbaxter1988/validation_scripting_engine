#!/usr/bin/env bash

cd ..

docker build .  -f docker/core.Dockerfile -t cbaxter1988/vse